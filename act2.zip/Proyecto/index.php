<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Captura de Datos</title>
        
        <link rel="stylesheet" href="style.css">
        </head>

  <body>
    <div class="dive" style="height: auto; min-height: 600px; padding-bottom: 50px;">
        <h1>Captura de datos personales</h1>
        <br>
        <h2>Ingresa los datos que se te piden</h2>
        <br>
        <p>Mi primera encuesta</p>
        <hr>

        <form action="resultados.php" method="POST">
            
            <label for="Name">Nombre</label>
            <input type="text" id="Name" name="Name" placeholder="Ingresa tu nombre" required/>
            <br><br>

            <label for="Edad">Edad</label>
            <input type="number" id="Edad" name="Edad" placeholder="Ingresa tu edad" required/>
            <br><br>

            <label for="Ciudad">Ciudad donde vives</label>
            <input type="text" id="Ciudad" name="Ciudad" placeholder="Ingresa tu ciudad" required/>
            <br><br>

            <label for="Fecha">Fecha de nacimiento</label>
            <input type="date" id="Fecha" name="Fecha" required/>
            <br><br>
            <label for="Pasatiempo">Pasatiempo favorito</label>
            <input type="text" id="Pasatiempo" name="Pasatiempo" placeholder="Ingresa tu pasatiempo" required/>
            <br><br>
            <button type="submit">Enviar Datos</button>
            
        </form>
        </div>
</body>
</html>