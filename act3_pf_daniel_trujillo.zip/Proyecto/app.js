// Definimos la clase CustomAlert
function CustomAlert() {
    
    // Función para mostrar la alerta
    this.render = function(dialog) {
        var winW = window.innerWidth;
        var winH = window.innerHeight;
        
        // Obtenemos los elementos del HTML
        var dialogoverlay = document.getElementById('dialogoverlay');
        var dialogbox = document.getElementById('popUpBox');
        
        // Mostramos la caja (cambiamos display none a block)
        dialogbox.style.display = "block";
        
        // Insertamos el mensaje y el botón de confirmación
        // Nota: El botón llama a la función Alert.ok()
        document.getElementById('dialogboxbody').innerHTML = dialog + '<br><br> <button onclick="Alert.ok()">Regresar al inicio</button>';
    }
    
    // Función para cerrar la alerta y volver al inicio
    this.ok = function() {
        document.getElementById('popUpBox').style.display = "none";
        // Redirecciona al index para capturar nuevos datos
        window.location = "index.php"; 
    }
}

// Inicializamos la variable global
var Alert = new CustomAlert();