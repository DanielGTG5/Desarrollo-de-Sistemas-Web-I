<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>¡Resultados de datos!</title>
        
        <link rel="stylesheet" href="style.css">
    </head>

   <body>
    <script src="app.js"></script>

    <div class="dive2">
        <h1>Resultados</h1>
        
<img src="foto.jpg" alt="Imagen de éxito" width="200">
        <div style="text-align: left; padding-left: 50px;">
            <?php
                // Verificamos si se enviaron datos para evitar errores
                if ($_POST) {
                    echo "<p><strong>Nombre:</strong> " . $_POST['Name'] . "</p>";
                    echo "<p><strong>Edad:</strong> " . $_POST['Edad'] . "</p>";
                    echo "<p><strong>Ciudad:</strong> " . $_POST['Ciudad'] . "</p>";
                    echo "<p><strong>Fecha de nacimiento:</strong> " . $_POST['Fecha'] . "</p>";
                    echo "<p><strong>Pasatiempo:</strong> " . $_POST['Pasatiempo'] . "</p>";
                }
            ?>
        </div>

        <h2>¡Bien Hecho!</h2>

        <button onclick="Alert.render('¿Deseas capturar un nuevo registro?')">Nueva Captura</button>

    </div>

    <div id="popUpBox">
        <div id="dialogboxbody"></div>
    </div>

</body>
</html>